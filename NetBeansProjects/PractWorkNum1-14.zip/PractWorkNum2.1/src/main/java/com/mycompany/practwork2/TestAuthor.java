/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practwork2;

/**
 *
 * @author Artem
 */
public class TestAuthor {

    public static void main(String[] args) {
        Author human = new Author("Барсик", "abcd@mail.com", 'F');
        System.out.println(human);
    }
}
