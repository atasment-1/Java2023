public class Student {
    int iDNumber, endScore;
    String name = "Виталик";

    public Student(int iDNumber, int endScore){
        this.iDNumber = iDNumber;
        this.endScore = endScore;
    }
}