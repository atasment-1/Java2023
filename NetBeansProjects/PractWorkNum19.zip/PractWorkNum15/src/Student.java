public class Student {
    String rollNo;
    String name;

    public String getName() {
        return name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}