public class StudentView {
    public void printStudentDetails(String studentName, String studentRollNo) {
        System.out.println("Данные студента:");
        System.out.println("Имя: " + studentName);
        System.out.println("Ролл №: " + studentRollNo);
    }
}
