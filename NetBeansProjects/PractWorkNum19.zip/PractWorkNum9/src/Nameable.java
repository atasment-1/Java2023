public interface Nameable {
    String getName();
}
