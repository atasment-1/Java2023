public interface Priceable {
    double getPrice();
}
